/*
 * tipo Competicion
 *  
 *  Atributos basicos
 *  
 *  	- pistasTotales: Tipo Pista[], consultable, 
 *  
 *  Atributos derivados
 *  
 *  Atributos estaticos
 *  
 *  Funcionalidades
 *  
 *  - toString
 *  
 *  Interfaz
 *  
 *  Restricciones
 * 
 */

public class Competicion {

}
