/*
 * tipo Partido
 * 
 * Atributos basicos
 * 
 * 		equipoLocal: tipo Equipo, consultable, modificable
 * 		equipoVisitante: tipo Equipo, consultable, modificable
 * 		golesLocal: small, consultable, modificable. (goles que MARCA el equipo local)
 * 		golesVisitante: small, consultable, modificable (goles que MARCA el equipo visitante)
 * 
 * Atributos derivados
 * 
 * 		-
 * 
 * Atributos est�ticos
 * 
 * 		-
 * 
 * Funcionalidades
 * 
 * 		decidirGanador: Decide quien es el ganador, en funcion de los goles, y le concede los puntos
 * 		correspondientes. Ademas, llama al metodo actualizarGoles de los objetos equipoLocal y equipoVisitante
 * 		para actualizar los goles totales
 * 
 * Interfaz
 * 
 * 		Constructores
 * 
 * 			public Partido()
 * 			public Partido(Equipo equipoLocal, Equipo equipoVisitante, short golesLocal, short golesVisitante)
 * 			public Partido(Partido p)
 * 
 * 		Getters
 * 
 * 			public Equipo getEquipoLocal()
 * 			public Equipo getEquipoVisitante()
 * 			public short getGolesLocal()
 * 			public short getGolesVisitante()
 * 
 * 		Setters
 * 
 * 			public void setEquipoLocal(Equipo equipoLocal)
 * 			public void setEquipoVisitante(Equipo equipoVisitante)
 * 			public void setGolesLocal(short golesLocal)
 * 			public void setgolesVisitante(short golesVisitante)
 * 
 * 		Funcionalidades
 * 
 * 			public void decidirGanador()
 * 
 */

package clasificacion;

public class Partido {

	private Equipo equipoLocal;
	private Equipo equipoVisitante;
	private short golesLocal;
	private short golesVisitante;
	
	public Partido() {
		
		this.equipoLocal = null;
		this.equipoVisitante = null;
		this.golesLocal = 0;
		this.golesVisitante = 0;
		
	}
	
	public Partido(Equipo equipoLocal, Equipo equipoVisitante, short golesLocal, short golesVisitante) {
		
		//Si alguno de los goles son negativos, se crea un objeto Partido por defecto
		
		if(golesLocal >= 0 && golesVisitante >= 0) {
			
			this.equipoLocal = equipoLocal;
			this.equipoVisitante = equipoVisitante;
			this.golesLocal = golesLocal;
			this.golesVisitante = golesVisitante;
			
		} else {
			
			this.equipoLocal = null;
			this.equipoVisitante = null;
			this.golesLocal = 0;
			this.golesVisitante = 0;
		}
		
	}
	
	public Partido(Partido p) {
		
		this.equipoLocal = p.equipoLocal;
		this.equipoVisitante = p.equipoVisitante;
		this.golesLocal = p.golesLocal;
		this.golesVisitante = p.golesVisitante;
		
	}
	
	public Equipo getEquipoLocal() {
		
		return this.equipoLocal;
		
	}
	
	public Equipo getEquipoVisitante() {
		
		return this.equipoVisitante;
		
	}
	
	public short getGolesLocal() {
		
		return this.golesLocal;
		
	}
	
	public short getGolesVisitante() {
		
		return this.golesVisitante;
		
	}
	
	public void setEquipoLocal(Equipo equipoLocal) {
		
		this.equipoLocal = equipoLocal;
		
	}
	
	public void setEquipoVisitante(Equipo equipoVisitante) {
		
		this.equipoVisitante = equipoVisitante;
		
	}
	
	public void setGolesLocal(short golesLocal) {
		
		if(golesLocal >= 0) {
			this.golesLocal = golesLocal;
		}
		
	}
	
	public void setGolesVisitante(short golesVisitante) {
		
		if(golesVisitante >= 0) {
			this.golesVisitante = golesVisitante;
		}
		
	}
	
	/*
	 * Analisis: Decide quien es el ganador, en funcion de los goles, y le concede los puntos
	 * correspondientes
	 * 
	 * Interfaz: public void decidirGandor()
	 * 
	 * Entradas: Ninguna
	 * 
	 * Salidas: Ninguna
	 * 
	 * Precondiciones: Ninguna
	 * 
	 * Postcondiciones: Tanto la puntuacion como los goles recibidos y marcados por el equipo seran legales
	 * 
	 */
	
	public void decidirGanador() {
		
		short puntuacionActualLocal = this.equipoLocal.getPuntuacion();
		short puntuacionActualVisitante = this.equipoVisitante.getPuntuacion();
		
		//Se actualiza la cantidad de goles marcados y recibidos por cada equipo
		equipoLocal.actualizarGoles(golesLocal, golesVisitante);
		equipoVisitante.actualizarGoles(golesVisitante, golesLocal);
		
		//Se actualiza la puntuacion de cada equipo
		if(this.golesLocal > this.golesVisitante) {
			
			this.equipoLocal.setPuntuacion((short) (3 + puntuacionActualLocal));
			
		} else if(this.golesLocal < this.golesVisitante) {
			
			this.equipoVisitante.setPuntuacion((short) (3 + puntuacionActualVisitante));
			
		} else if (this.golesLocal == this.golesVisitante) {
			
			this.equipoLocal.setPuntuacion((short) (1 + puntuacionActualLocal));
			this.equipoVisitante.setPuntuacion((short) (1 + puntuacionActualVisitante));
			
		}
		
	}
	
}
