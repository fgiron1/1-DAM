/*
 * tipo Equipo
 * 
 * 	Atributos basicos
 * 
 *		nombre: String, consultable, no modificable
 *		puntuacion: short, consultable, modificable
 *		partidosJugados: ArrayList<Partido>, consultable, modificable
 *		golesMarcados: short, consultable, modificable
 *		golesRecibidos: short, consultable, modificable
 *
 *	Atributos derivados
 *
 *		-
 *
 *	Atributos estaticos
 *
 *		-
 *
 *	Funcionalidades
 *
 *		actualizarGoles: Actualiza la cantidad total de goles marcados y recibidos por el equipo.
 *		Este metodo esta pensado para ser usado por la clase Partido, de tal forma que al finalizar
 *		un partido y modificar la puntuacion del equipo correspondiente a traves de un setter,
 *		tambien actualizaremos los goles totales llamando a este metodo
 *
 *		compareTo: Compara dos equipos segun el criterio de ordenacion. En este caso, el criterio
 *		de ordenacion sera la puntuacion de cada equipo en la clasificacion
 *		
 *		toString: Imprime por pantalla el nombre del equipo, su puntuacion en la liga, la cantidad
 *		de partidos jugados, y los goles marcados y recibidos totales
 * 
 * 
 * 	Interfaz:
 * 
 * 		Constructores:
 * 
 * 			public Equipo(String nombre)
 * 			public Equipo(String nombre, short puntuacion, ArrayList<Partido> partidosJugados, short golesMarcados, short golesRecibidos)
 * 			public Equipo(Equipo e)
 * 
 * 		Getters:
 * 
 * 			public String getNombre()
 * 			public short getPuntuacion()
 * 			public ArrayList<Partido> getPartidosJugados()
 * 			public short getGolesMarcados()
 * 			public short getGolesRecibidos()
 * 
 * 		Setters:
 * 
 * 			public void setPuntuacion(short puntuacion)
 * 			public void setPartidosJugados(Partido jugado)
 * 			public void setPartidosJugados(ArrayList<Partido> partidosJugados)
 * 			public void setGolesMarcados(short golesMarcados)
 * 			public void setGolesRecibidos(short golesRecibidos)
 * 
 * 		Funcionalidades:
 * 
 * 			public void actualizarGoles(short incrementoGolesMarcados, short incrementoGolesRecibidos)
 * 			public int compareTo(Equipo e)
 * 			public String toString()
 * 
 */


package clasificacion;

import java.util.ArrayList;

public class Equipo implements Comparable<Equipo>{
	
	private String nombre;
	private short puntuacion;
	private ArrayList<Partido> partidosJugados;
	private short golesMarcados;
	private short golesRecibidos;
	
	//Constructores
	
	public Equipo(String nombre) {
		
		this.nombre = nombre;
		this.puntuacion = 0;
		this.partidosJugados = new ArrayList<Partido>();
		this.golesMarcados = 0;
		this.golesRecibidos = 0;
		
	}
	
	public Equipo(String nombre, short puntuacion, ArrayList<Partido> partidosJugados, short golesMarcados, short golesRecibidos) {
		
		//Si los valores numericos pasados por parametros son invalidos, se crea un objeto Equipo con
		//los campos numericos por defecto y con el nombre pasado por parametros
		
		if(puntuacion >= 0 && partidosJugados.size() >= 0 && golesMarcados >= 0 && golesRecibidos >= 0) {
			
			this.nombre = nombre;
			this.puntuacion = puntuacion;
			this.partidosJugados = partidosJugados;
			this.golesMarcados = golesMarcados;
			this.golesRecibidos = golesRecibidos;
			
		} else {
			new Equipo(nombre);
		}
	}
	
	public Equipo(Equipo e) {
		
		this.nombre = e.nombre;
		this.puntuacion = e.puntuacion;
		this.golesMarcados = e.golesMarcados;
		this.golesRecibidos = e.golesRecibidos;
		
		for(int i = 0; i < e.partidosJugados.size(); i++) {
			
			//A traves del constructor de copia de la clase Partido, se copian cada uno de los partidos
			//de e.partidosJugados en el ArrayList this.partidosJugados, consiguiendo una copia profunda
			
			this.partidosJugados.add(new Partido(e.partidosJugados.get(i)));
			
		}
	}
	
	public String getNombre() {
		
		return this.nombre;
		
	}
	
	public short getPuntuacion() {
		
		return this.puntuacion;
		
	}
	
	public ArrayList<Partido> getPartidosJugados(){
		
		//Se copia el arrayList a traves del constructor de copia de la clase ArrayList
		ArrayList<Partido> copiaPartidosJugados = new ArrayList<Partido>(this.partidosJugados);
		return copiaPartidosJugados;
		
	}
	
	public short getGolesMarcados() {
		
		return this.golesMarcados;
		
	}
	
	public short getGolesRecibidos() {
		
		return this.golesRecibidos;
		
	}
	
	public void setPuntuacion(short puntuacion) {
		
		//Si se introduce una puntuacion negativa o 0, no se actualiza el valor
		
		if(puntuacion > 0) {
			this.puntuacion = puntuacion;
		}
		
	}
	
	public void setPartidosJugados(Partido jugado) {
		
		this.partidosJugados.add(jugado);
		
	}
	
	public void setPartidosJugados(ArrayList<Partido> partidosJugados) {
		
		this.partidosJugados = partidosJugados;
		
	}
	
	public void setGolesMarcados(short golesMarcados) {
		
		if(golesMarcados >= 0) {
			
			this.golesMarcados = golesMarcados;
			
		}
		
	}
	
	public void setGolesRecibidos(short golesRecibidos) {
		
		if(golesRecibidos >= 0) {
			
			this.golesRecibidos = golesRecibidos;
			
		}
		
	}
	
	/*
	 * Analisis: Actualiza la cantidad total de goles marcados y recibidos por el equipo.
	 * Este metodo esta pensado para ser usado por la clase Partido, de tal forma que al finalizar
 	 * un partido y modificar la puntuacion del equipo correspondiente a traves de un setter,
 	 * tambien actualizaremos los goles totales llamando a este metodo
	 * 
	 * Entradas: El incremento de los goles marcados y los goles recibidos
	 * 
	 * Salidas: Ninguna
	 * 
	 * Interfaz: public void actualizarGoles(short incrementoGolesMarcados, short incrementoGolesRecibidos)
	 * 
	 * Precondiciones: Ambos parametros seran positivos
	 * 
	 * Postcondiciones: La puntuacion del equipo sera positiva 
	 * 
	 */

	public void actualizarGoles(short incrementoGolesMarcados, short incrementoGolesRecibidos) {
		
		this.golesMarcados += incrementoGolesMarcados;
		this.golesRecibidos += incrementoGolesRecibidos;
		
	}
	
	@Override
	public int compareTo(Equipo e) {
		
		int valor;
		
		if(this.puntuacion > e.puntuacion) {
			valor = 1;
		} else if(this.puntuacion < e.puntuacion) {
			valor = -1;
		} else {
			valor = 0;
		}
		
		return valor;
	}
	
	@Override
	public String toString() {
		
		String devolver;
		
		devolver = "Equipo: "+this.nombre+
				   "\nPuntuacion: "+this.puntuacion+
				   "\nPartidos jugados: "+this.partidosJugados.size()+
				   "\nGoles marcados: "+this.golesMarcados+
				   "\nGoles recibidos: "+this.golesRecibidos;
		
		return devolver;
		
	}
}
