package clasificacion;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class EquipoTest {

	@Test
	void testEquipoString() {
		
		ArrayList<Partido> vacio = new ArrayList<Partido>();
		
		//COMPROBACION: Se pueden crear equipos con nombres con espacios y caracteres especiales
		Equipo prueba1 = new Equipo("3�@   _-*''");
		assertEquals("3�@   _-*''", prueba1.getNombre());
		assertEquals(vacio, prueba1.getPartidosJugados());
		assertEquals(0, prueba1.getGolesMarcados());
		assertEquals(0, prueba1.getGolesRecibidos());
		assertEquals(0, prueba1.getPuntuacion());
		
	}

	@Test
	void testEquipoStringShortArrayListOfPartidoShortShort() {
		
		ArrayList<Partido> vacio = new ArrayList<Partido>();
		
		//COMPROBACION: Se crea un equipo por defecto cuando los valores pasados no son validos
		
		//Primero probamos el correcto funcionamiento del constructor
		Equipo valido = new Equipo("Hey", (short) 2, vacio, (short) 2, (short) 2);
		assertEquals("Hey", valido.getNombre());
		assertEquals(vacio, valido.getPartidosJugados());
		assertEquals((short) 2, valido.getPuntuacion());
		assertEquals((short) 2, valido.getGolesMarcados());
		assertEquals((short) 2, valido.getGolesRecibidos());
		
		//TODO Cuando en el else le pongo new Equipo(nombre), se crea ese objeto pero al salir
		//de los corchetes del else ya se ha perdido
		//Como solucion pues voy a inicializar los parametros ahi mismo sin llamar al constructor
		//por defecto
		Equipo valido2 = new Equipo("Alberto", (short) -2, vacio, (short) 2, (short) 2);
		assertEquals("Alberto", valido2.getNombre());
		assertEquals(vacio, valido.getPartidosJugados());
		assertEquals((short) 0, valido2.getPuntuacion());
		assertEquals((short) 0, valido2.getGolesMarcados());
		assertEquals((short) 0, valido2.getGolesRecibidos());
		
	}

	@Test
	void testEquipoEquipo() {
		
	}

	@Test
	void testGetPartidosJugados() {
		
	}

	@Test
	void testSetPuntuacion() {
		
	}

	@Test
	void testSetPartidosJugadosPartido() {
		
	}

	@Test
	void testSetPartidosJugadosArrayListOfPartido() {
		
	}

	@Test
	void testSetGolesMarcados() {
		
	}

	@Test
	void testSetGolesRecibidos() {
		
	}

	@Test
	void testActualizarGoles() {
		
	}

	@Test
	void testCompareTo() {
		
	}

}
