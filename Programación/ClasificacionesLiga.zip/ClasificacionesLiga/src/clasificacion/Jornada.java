/*
 * tipo Jornada
 * 
 * Atributos basicos
 * 
 * 		partidos: tipo Partido[], consultable, modificable
 * 
 * Atributos derivados
 * 
 * 		numeroJornada: short, consultable, no modificable (Derivado de cantidadJornadas)
 * 
 * Atributos estaticos
 * 
 * 		cantidadJornadas: short, consultable, no modificable 
 * 		(Aumenta en 1 cada vez que se crea un objeto Jornada)
 * 
 * Funcionalidades
 * 
 * Interfaz
 * 
 * 		Constructores
 * 		
 * 			public Jornada()
 * 			public Jornada(Partido[] partidos)
 * 			public Jornada(Jornada j)
 * 
 * 		Getters
 * 
 * 			public Partido[] getPartidos()
 * 			public short getNumeroJornada()
 * 			public short getCantidadJornadas()
 * 
 * 		Setters
 * 
 * 			public void setPartidos(Partido p)
 * 			public void setPartidos(Partido[] partidos)
 * 
 */
package clasificacion;
public class Jornada {
	
	private Partido[] partidos;
	private short numeroJornada;
	private static short cantidadJornadas = 0;
	//Se incrementa en uno el valor de cantidadJornadas cada vez que se instancia un objeto a traves
	//de cualquiera de los constructores
	
	public Jornada(){
		
		cantidadJornadas++;
		
		this.partidos = new Partido[10];
		this.numeroJornada = cantidadJornadas;
		
	}
	
	public Jornada(Partido[] partidos) {
		
		cantidadJornadas++;
		
		this.numeroJornada = cantidadJornadas;
		this.partidos = partidos;
		
	}
	
	public Jornada(Jornada j) {
		
		cantidadJornadas++;
		this.numeroJornada = cantidadJornadas;
		
		for(int i = 0; i < j.partidos.length; i++) {
			//Se copia cada partido del array j.partidos, a traves del constructor de copia
			//de la clase Partido, en
			this.partidos[i] = new Partido(j.partidos[i]);
		}
		
	}
	
	public Partido[] getPartidos() {
		
		Partido[] copiaPartidos = new Partido[this.partidos.length];
		
		for(int i = 0; i < this.partidos.length; i++) {
			copiaPartidos[i] = new Partido(this.partidos[i]);
		}
		
		return copiaPartidos;
		
	}
	
	public short getNumeroJornada() {
		
		return this.numeroJornada;
		
	}
	
	public short getCantidadJornadas() {
		
		return cantidadJornadas;
		
	}
	
	public void setPartidos(Partido p) {
		
		
	}
	
	public void setPartidos(Partido[] partidos) {
		
		//Se tendria que clonar cada partido porque la referencia se tiene desde fuera ya (porque si
		//se la pasan es que la tienen) y pueden acceder al objeto sin usar el getter
		
		this.partidos = partidos;
		
	}

}
