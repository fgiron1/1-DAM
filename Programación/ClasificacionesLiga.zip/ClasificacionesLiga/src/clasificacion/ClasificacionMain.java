/*
 * 
 * Las jornadas son de 10 partidos.
 * 
 * En la liga hay N equipos
 * 
 * No hay limite de jornadas
 * 
 * 
 * 
 * 
 * Entradas: Cantidad de equipos de la liga, opcion menu, el nombre de cada equipo, goles a favor  y en contra de cada equipo de cada partido para cada jornada,  la decision de salir del programa
 * 
 * Salidas: 
 * 
 * PSEUDOCODIGO GENERALIZADO
 * 
 * <Inicio>
 * 		Pedir cantidad de equipos a participar
 * 		Validar cantidad de equipos a participar
 * 		FOR(hasta cantidad de equipos)
 * 			Pedir nombre de equipo
 * 		FIN_FOR
 * 
 * 		Pedir datos de los partidos de primera jornada
 * 		Validar datos de los partidos de primera jornada
 * 		Crear partidos
 * 		Actualizar equipos
 * 		DO
 * 			Presentar menu opciones (1 -> Insertar datos nueva jornada, 2 -> Mostrar clasificacion, 3 -> Salir)
 * 			SWITCH(opcion)
 * 				CASE 1: Pedir datos nueva jornada
 * 						Validar datos nueva jornada
 * 						Crear partidos
 * 						Actualizar equipos
 * 				CASE 2: Ordenar equipos por puntuacion
 * 						Mostrar tabla con la informacion de los equipos
 * 				CASE 3: Salir del programa
 * 				DEFAULT: Opcion introducida es incorrecta, por favor introduzca otra
 * 				
 * 
 *  	WHILE(no quiera salir)
 *  
 * <Fin>
 * 
 * RESTRICCIONES: Todos los equipos deben tener nombres distintos y no pueden tener espacios
 * 
 */

package clasificacion;

import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class ClasificacionMain {

	//Se declaran las variables jornadasTotales y equiposTotales como estaticas para poder hacer uso de ellas
	//en todos los metodos del main sin tener que pasarselas por parametros
	
	private static ArrayList<Jornada> jornadasTotales = new ArrayList<Jornada>();
	private static Equipo[] equiposTotales;
	private static Scanner input = new Scanner(System.in);
	
	public static void main(String[] args) {
		
		//Declaracion e instanciacion de variables de tipos primitivos
		int cantidad, opcionMenu;
		boolean salir = false;
		
		//Declaracion e instanciacion de objetos
		String nombreEquipo;
		
		//Se pide la cantidad de equipos que van a participar en la liga
		System.out.print("Introduzca la cantidad de equipos que van a participar (maximo 50): ");
		
		//Se valida la cantidad introducida
		do {
			cantidad = input.nextInt();
			if(cantidad <= 0 || cantidad > 50) {
				System.out.print("Por favor, introduzca una cantidad valida: ");
			}
		}while(cantidad <= 0 || cantidad > 50);
		
		//Se inicializa el array de equipos con el tamanho especificado
		equiposTotales = new Equipo[cantidad];
		
		for(int i = 0; i < cantidad; i++) {
			
			System.out.print("Introduzca el nombre del equipo "+(i+1)+": ");
			
			nombreEquipo = input.next();
			
			//Se instancian cada objeto Equipo con el nombre correspondiente, el resto de 
			//atributos toma sus valores por defecto
			equiposTotales[i] = new Equipo(nombreEquipo);
			
		}
		
		
		//El menu principal se volvera a mostrar despues de cada accion hasta que se elija salir
		
		do {
			
			System.out.print("\nMe gustaria...");
			System.out.print("\n1. Introducir datos de una nueva jornada");
			System.out.print("\n2. Mostrar clasificacion actual");
			System.out.print("\n3. Salir");
			System.out.print("\n\nIntroduzca su eleccion: ");
			
			do {
				opcionMenu = input.nextInt();
				if(opcionMenu < 1 || opcionMenu > 3) {
					System.out.print("Por favor, introduzca un numero del 1 al 3: ");
				}
			}while(opcionMenu < 1 || opcionMenu > 3);
		
			salir = menuPrincipal(opcionMenu);
			
		}while(!salir);
		
		do {
			
			
		}while(!salir);
			
		input.close();
	}
	
	
	/*
	 * Analisis: Este metodo le pide al usuario los datos de cada partido (hasta 10) de una jornada e
	 * instancia los objetos Partido con dichos datos. Finalmente, instancia un objeto Jornada
	 * con el array de objetos Partido creado
	 *
	 * Interfaz: public static void crearJornada()
	 * 
	 * Entradas: Ninguna
	 * 
	 * Salidas: Ninguna
	 * 
	 * Precondiciones: 
	 * 
	 * Postcondiciones: 
	 * 
	 */
	
	public static void crearJornada(){
		
		String nombreLocal, nombreVisitante;
		short golesLocal, golesVisitante;
		Partido[] partidosTotales = new Partido[10];
		
		//Se instancia un objeto Jornada por defecto
		Jornada nuevaJornada = new Jornada();
		
		System.out.print("\nIntroduzca los datos de la jornada "+nuevaJornada.getNumeroJornada()+": ");
		
		//El bucle se repite 10 veces debido a que en cada jornada hay 10 partidos
		for(int i = 0; i < 10; i++) {
			
			System.out.print("\n\nPartido "+(i+1));
			System.out.print("\nEquipo local: ");
			
			//Validamos el nombre introducido (verificamos que existe un equipo con ese nombre)
			do {
				nombreLocal = input.next();
				//Si el objeto devuelto es null significa que no hay ninguna coincidencia
				if(Objects.isNull(buscarEquipoPorNombre(nombreLocal))) {
					System.out.print("No existe ningun equipo con ese nombre. Introduzca otro nombre: ");
				}
				
			}while(Objects.isNull(buscarEquipoPorNombre(nombreLocal)));
			
			//Se almacena una referencia al equipo local
			Equipo local = buscarEquipoPorNombre(nombreLocal);
			
			System.out.print("Equipo visitante: ");
			
			//Validamos el nombre introducido (verificamos que existe un equipo con ese nombre y que el equipo
			//visitante no sea el mismo que el equipo local)
			do {
				nombreVisitante = input.next();
				//Si el objeto devuelto es null significa que no hay ninguna coincidencia
				if(Objects.isNull(buscarEquipoPorNombre(nombreVisitante))) {
					System.out.print("No existe ningun equipo con ese nombre. Introduzca otro nombre: ");
				} else if(nombreVisitante.equals(nombreLocal)) {
					System.out.print("Un equipo no puede jugar contra si mismo. Introduzca otro nombre: ");
				}
				
			}while(Objects.isNull(buscarEquipoPorNombre(nombreVisitante)) || nombreVisitante.equals(nombreLocal));
			
			//Se almacena una referencia al equipo visitante 
			Equipo visitante = buscarEquipoPorNombre(nombreVisitante);
			
			System.out.print("Goles del equipo local: ");
			
			//Validamos los goles del equipo local
			do {
				golesLocal = input.nextShort();
				if(golesLocal < 0) {
					System.out.print("Numero invalido, por favor introduzca un numero mayor o igual a 0: ");
				}
				
			}while(golesLocal < 0);
			
			System.out.print("Goles del equipo visitante: ");
			
			//Validamos los goles del equipo local
			do {
				golesVisitante = input.nextShort();
				if(golesVisitante < 0) {
					System.out.print("Numero invalido, por favor introduzca un numero mayor o igual a 0: ");
				}
				
			}while(golesVisitante < 0);

			
			//Se crea un partido con los datos introducidos y se almacena en un array
			Partido nuevoPartido = new Partido(local, visitante, golesLocal, golesVisitante);
			partidosTotales[i] = nuevoPartido;
			
			//Se actualizan las puntuaciones, goles marcados y recibidos por cada equipo
			nuevoPartido.decidirGanador();
			
			//Ademas, cada equipo guarda una referencia del partido que han jugado
			local.setPartidosJugados(nuevoPartido);
			visitante.setPartidosJugados(nuevoPartido);
			
		}
		
		//Se asignan los partidos almacenados a la jornada
		
		nuevaJornada.setPartidos(partidosTotales);
		
		//Se aniade la jornada al arrayList estatico de jornadas 
		jornadasTotales.add(nuevaJornada);
		
		
	}
	
	/*
	 * Analisis: Este metodo busca un equipo en el array de equiposTotales por su nombre. 
	 * Si lo encuentra, devuelve una referencia a dicho objeto, sino, devuelve un objeto Equipo null
	 * 
	 * Interfaz: public static Equipo buscarEquipoPorNombre(String nombre)
	 * 
	 * Entradas: El nombre del equipo a buscar
	 * 
	 * Salidas: El equipo cuyo nombre coincide (salvo mayusculas) con el nombre pasado por parametros
	 * o bien null, indicando que no existe ningun equipo con tal nombre.
	 * 
	 * Precondiciones: 
	 * 
	 * Postcondiciones: 
	 * 
	 */
	
	public static Equipo buscarEquipoPorNombre(String nombre) {
		
		Equipo devolver = null;
		boolean encontrado = false;
		
		
		for(int i = 0; i < equiposTotales.length; i++) {
			
			//Comparamos el nombre pasado por parametros con el nombre de cada equipos
			//El metodo equalsIgnoreCase devolvera true si las cadenas comparadas son de la misma
			//longitud y tienen los mismos caracteres, independientemente de si son o no mayusculas
			
			//En la primera coincidencia de nombre, acabara el bucle. No es un problema realmente
			//porque se ha puesto la restriccion de que todos los equipos tengan nombres distintos
			if(nombre.equalsIgnoreCase(equiposTotales[i].getNombre()) && !encontrado) {
			
				devolver = equiposTotales[i];
				encontrado = true;
			}
		}
		
		return devolver;
		
	}
	
	/*
	 * Analisis: Este metodo ejecuta una funcionalidad del menu principal en funcion de la opcion
	 * pasada por parametros
	 * 
	 * Interfaz: public boolean menuPrincipal(int opcion)
	 * 
	 * Entradas: La eleccion de una opcion del menu (1, 2 o 3)
	 * 
	 * Salidas: Un booleano que expresa si se quiere finalizar el programa o no
	 * 
	 * Precondiciones: La opcion pasada por parametros esta validada
	 * 
	 * Postcondiciones: Ninguna
	 * 
	 */
	
	public static boolean menuPrincipal(int opcion) {
		
		boolean salir = false;
		
		switch(opcion) {
		
		case 1:
			
			crearJornada();
			break;
			
		case 2:
			
			//Se orden el array de equipos
			Utiles.ordenarInsercionDirecta(equiposTotales);
			
			//Se imprime la informacion de los equipos ordenados
			for(int i = 0; i < equiposTotales.length; i++) {
				System.out.print(equiposTotales[i].toString()+"\n\n");
			}
			
			break;
		
		case 3:
			
			salir = true;
			break;
		
		}
			
		return salir;
		
	}
		
}



