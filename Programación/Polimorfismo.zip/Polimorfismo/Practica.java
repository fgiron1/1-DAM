package Practica;

public class Practica{

	
	/*
	 * Analisis: Este metodo ordena un array de objetos a traves del metodo de seleccion directa
	 * 
	 * Interfaz: public static void ordenarSeleccionDirecta(Comparable[] cosas)
	 * 
	 * Entradas: cosas: Un array de objetos de tipo generico Comparable[]
	 * 
	 * Salidas: Ninguna
	 * 
	 * Precondiciones: La clase a la que pertenezcan los objetos del array deben implementar
	 * la interfaz comparable parametrizada y el metodo compareTo
	 * 
	 * Postcondiciones: El array estara ordenado de manera ascendente segun el criterio de ordenacion
	 * 
	 */
	
	//Metodo de seleccion directa.
	
	//FUNCIONAMIENTO
	//Se busca y selecciona el menor elemento de la parte no ordenada y se coloca en el
	//siguiente lugar de la parte ordenada
	
	public static void ordenarSeleccionDirecta(Comparable[] cosas) {
		
		int minimo;
		Comparable aux;
		
		for(int i = 0; i < cosas.length; i++) {
			minimo = i;
			//Cuando acaba todas las iteraciones del segundo bucle for, el indice minimo apunta al elemento
			//mas peque�o de la parte no ordenada
			for(int j = 0; j < cosas.length; j++) {
				if(cosas[j].compareTo(cosas[i]) < 0) {
					minimo = j;
				}
			}
			//Como minimo apunta al elemento mas peque�o,
			aux = cosas[i];
			cosas[i] = cosas[minimo];
			cosas[minimo] = aux;
				
		}
		
	}
	
	/*
	 * Analisis: Este metodo ordena un array de objetos a traves del metodo de insercion directa
	 * 
	 * Interfaz: public static void ordenarInsercionDirecta(Comparable[] cosas)
	 * 
	 * Entradas: cosas: Un array de objetos de tipo generico Comparable[]
	 * 
	 * Salidas: Ninguna
	 * 
	 * Precondiciones: La clase a la que pertenezcan los objetos del array deben implementar
	 * la interfaz comparable parametrizada y el metodo compareTo
	 * 
	 * Postcondiciones: El array estara ordenado de manera ascendente segun el criterio de ordenacion
	 * 
	 */
	
	
	//Metodo de insercion directa
	
	//FUNCIONAMIENTO
	//Aqui se asume el primer elemento del array como ordenado y el resto se ordenan en funcion de el.
	//De tal forma que, en todo momento, el siguiente por ordenar se coloca en la posicion correspondiente
	//de la parte ordenada del array

	public static void ordenarInsercionDirecta(Comparable[] cosas) {
		
		Comparable aux;
		
		for(int i = 0; i < cosas.length; i++) {
			for(int j = i; j > 0 && cosas[j-1].compareTo(cosas[j]) > 0; j--) {
					aux = cosas[j-1];
					cosas[j-1] = cosas[j];
					cosas[j] = aux;
			}
		}

	}	

	
}
