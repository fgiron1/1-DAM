public class Validar{
	
	public boolean validarDNI(String dni){
	
		boolean juicio = false;
		
		if(esCadenaDeEnteros(dni.substring(0, 6)) && Character.isUpperCase(dni.charAt(7))) {
			
			juicio = true;
			
		}
		
		return juicio;
		
	}
	
	private boolean esCadenaDeEnteros(String cadena) {
		
		boolean juicio;
		
		try{
			Integer.parseInt(cadena);
			juicio = true;
			
			} catch (NumberFormatException nfe) {
			juicio = false;
			
			}
		
			return juicio;
		
		}
		
	
	
}
