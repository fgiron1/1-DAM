/*
 * 
 * DUDA: �LA VALIDACION DE DATOS LA DEBERIA HACER EN LA CLASE O EN LOS PROGRAMAS QUE LA USEN?
 * 
 * 
 * tipo DNI
 * 
 * Atributos basicos
 * 
 * 		numero: String, consultable, no modificable
 * 		letra: char, consultable, no modificable
 * 
 * Atributos derivados
 * 
 * 		-
 * 
 * Atributos estaticos
 * 
 * 		letraValor: char[], consultable, no modificable
 * 
 * Funcionalidades
 * 
 * 		-
 * 
 * Interfaz
 * 
 * 		Metodos privados:
 * 
 * 				private static boolean validarDNI(String numero, char letra)
 * 
 * 		Metodos publicos:
 * 
 * 				public boolean letraValida()
 * 
 * Restricciones
 * 
 * 		-
 * 
 */

public class DNI implements Comparable<DNI>{
	
	
	private String numero;
	private char letra;
	private static char[] letraValor = {'T','R','W','A','G','M','Y','F','P','D','X','B','N','J','Z','S','Q','V','H','L','C','K','E'};
	private static Validar validador = new Validar();
	
	//Constructores
	
	public DNI(){ //Constructor sin parámetros
		
		this.numero = "00000000";
		this.letra = 'X';
		
	}
	
	public DNI(String dni){ //Constructor con parametros
		
		if(validador.validarDNI(dni)){ //Aqui se comprueban que sean 8 numeros y una letra mayuscula al final
			
			this.numero = dni.substring(0, 6);
			this.letra = dni.charAt(7);
			
		} else {
			
			new DNI();
			
		}
		
	}
	
	public DNI(DNI a){ //Constructor de copia
		
		this.numero = a.numero;
		this.letra = a.letra;
		
	}
	
	public boolean letraValida(){
		
		boolean valido = false;
		int numeroInt = Integer.parseInt(numero);   //Pasamos el numero expresado como String a int (se hace unboxing para pasar de Integer a int)
		boolean letraValida = this.letraValor[numeroInt % 23] == this.letra; //Comprobamos que la letra a la que le corresponde el numero modulo 23 es la letra introducida
		
		return letraValida;
		
	}
	
	
	public String getNumero(){
		
		return this.numero;
		
	}
	
	public char getLetra(){
		
		return this.letra;
		
	}
	
	public char[] getLetraValor(){
		
		return this.letraValor;
		
	}
	
	@Override
	public String toString(){
		
		return numero+String.valueOf(letra);
		
	}
	
	@Override
	//Criterio de ordenacion: Ordenacion por letra
	public int compareTo(DNI a) { 
		
		int comparacion;
		
		Character aComparar = new Character(this.letra);
		Character compararCon = new Character(a.letra);
		
		comparacion = aComparar.compareTo(compararCon);
				
		return comparacion;
		
	}
	
}
